var folder = "";

if (!cc.sys.isNative)
{
    folder = "res/mediumRes/";
}

var res = {
    HelloWorld_png : folder + "HelloWorld.png",
    CloseNormal_png : folder + "CloseNormal.png",
    CloseSelected_png : folder+ "CloseSelected.png",
    Main_Music : "res/Sound/MainMusic.ogg"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}